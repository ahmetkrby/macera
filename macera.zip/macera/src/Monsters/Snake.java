package Monsters;

import java.util.Random;

public class Snake extends Obstacle{
    public Snake() {
        super("Snake", 4, 0, 0, 0);
    }


}
