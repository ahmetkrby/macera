package Monsters;

import Monsters.Obstacle;

public class Vampire extends Obstacle {
    public Vampire() {
        super("Vampir", 2, 14, 4, 7);
    }
}
