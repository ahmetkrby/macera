package Monsters;

public class Bear extends Obstacle {

    public Bear() {
        super("Ayı", 3, 20, 7,12);
    }
}
