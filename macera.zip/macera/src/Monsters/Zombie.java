package Monsters;

import Monsters.Obstacle;

public class Zombie extends Obstacle {
    public Zombie() {
        super("Zombi", 1, 10, 3,4);
    }
}
