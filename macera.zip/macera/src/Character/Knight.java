package Character;

public class Knight extends GameCharacter {
    public Knight() {
        super(3,"Şövalye",8, 24, 25);
    }
}
